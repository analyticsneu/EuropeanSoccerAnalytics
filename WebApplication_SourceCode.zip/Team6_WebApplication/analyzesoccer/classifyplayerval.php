<?php 
$servername="analyzesoccer.database.windows.net";

$connectionInfo=array("Database"=>"analyzesoccer","UID"=>"soccer","PWD"=>"himaja@12345");

$conn = sqlsrv_connect($servername, $connectionInfo);

if($conn){
	echo "Connect.<br/>";
}else{
	echo "Connection fail.<br/>";
	die(print_r(sqlsrv_errors(), true));
}

//$tsql2 = "SELECT distinct([home_team_name]), [home_team_api_id] FROM englishpremierleague";
$tsql3 = "SELECT [player_api_id], [player_name] FROM [dbo].[player]";

$getplayername = sqlsrv_query($conn, $tsql3);

//sqlsrv_free_stmt($getleague);
				
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Analyse Soccer</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	<link rel="icon" type="image/png" href="img/Soccer-icon.png">
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="about.html"><b>Sports Analytics - Predicting and Classifying A Soccer Dataset</b></a>
            </div>
            
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="about.html">&nbsp;<i class="fa fa-info-circle" aria-hidden="true"></i> &nbsp;About</a>
                    </li>
					<li>
                        <a href="index.html"><i class="fa fa-fw fa-dashboard"></i>D3 Visualizations</a>
                    </li>                    
                   <!-- <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><!--<i class="fa fa-fw fa-arrows-v"></i>
						<i class="fa fa-area-chart" aria-hidden="true"></i> Prediction<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
								<a href="predictscore.php"><!--<i class="fa fa-fw fa-edit"></i>
								<i class="fa fa-circle-o" aria-hidden="true"></i> Match Score</a>
							</li>
                            <li>
								<a href="predictbetodds.html"><!--<i class="fa fa-fw fa-edit"></i>
								<i class="fa fa-circle-o" aria-hidden="true"></i> Betting Odds</a>
							</li>
                        </ul>
                    </li>-->
					<!--<li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo1"><!--<i class="fa fa-fw fa-arrows-v"></i>
						<i class="fa fa-area-chart" aria-hidden="true"></i> Classification <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo1" class="collapse">
                            <li>
								<a href="classifyplayerval.php"><!--<i class="fa fa-fw fa-edit"></i>
								<i class="fa fa-circle-o" aria-hidden="true"></i> Player Valuation</a>
							</li>
                            <li>
								<a href="classifygameresult.php"><!--<i class="fa fa-fw fa-edit"></i>
								<i class="fa fa-circle-o" aria-hidden="true"></i> Game Result</a>
							</li>
                        </ul>
                    </li>-->
					<li class="active">
						<a href="classifyplayerval.php">
                        <i class="fa fa-area-chart" aria-hidden="true"></i> Player Valuation</a>
                    </li>
					<li>
						<a href="classifygameresult.php"><!--<i class="fa fa-fw fa-edit"></i>-->
								<i class="fa fa-area-chart" aria-hidden="true"></i> Game Result</a>                        
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <div align="center">
						<h1 class="page-header">
                            <strong>Player Valuation</strong>
							<?php
/*
							echo "PHP works here";
											
				$league1='1';
				$season1='2013/2014';
				$hteam1='8667';
				$ateam1='8197';
				$b365h1='1.1';
				$b365d1='1.1';
				$b365a1='1.1';
				$bwh1='1.1';
				$bwd1='1.1';
				$bwa1='1.1';
				
				$pyscript = 'D:\\home\\site\\wwwroot\\analyzesoccer\\python\\predictscore.py';
				$python = 'D:\\Python34\\python.exe';
				
				//**there has to be a space after $pyscript**
				$cmd = "$python $pyscript " .$league1." ".$season1." ".$hteam1." ".$ateam1." ".$b365h1." ".$b365d1." ".$b365a1." ".$bwh1." ".$bwd1." ".$bwa1;
				echo $cmd;
				
				exec("$cmd", $output);
				echo $output[0];
				$comma = ',';
				//echo $output[1].$comma.$output[2].$comma.$output[3].$comma.$output[4].$comma.$output[5].$comma.$output[6].$comma.$output[7].$comma.$output[7];
							
							
					*/		
							?>
                        </h1>
						</div>                        
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-6">

                        <form role="form">
																	
							<div class="form-group">
                                <label>Player Name</label>
                                <select class="form-control" id="pname">
                                    <option value="">Select Player Name</option>
									<?php 
							if ($getplayername == FALSE)  
							die(FormatErrors(sqlsrv_errors()));  							
							while($row = sqlsrv_fetch_array($getplayername, SQLSRV_FETCH_ASSOC))  
								{ 
								echo "<option value=" . $row['player_api_id'] . ">" . $row['player_name'] . "</option>"; 
								} 
									?>									
                                </select>
                            </div>
						
							<div class="form-group">						
                                <label>Overall Rating</label>
                                <input type="text" class="form-control" id="rating">
								<!--<select class="form-control" id="rating">
                                    <option>86</option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
                                </select>-->
                            </div>
						
							<div class="form-group">
                                <label>Potential</label>
                                <input type="text" class="form-control" id="potential">
								<!--<select class="form-control" id="potential">
                                    <option>75</option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
                                </select>-->
                            </div>
							
							<div class="form-group">
                                <label>Age</label>
                                <input type="text" class="form-control" id="age">
								<!--<select class="form-control" id="age">
                                    <option>18</option>
									<option>19</option>
									<option>20</option>
									<option>21</option>
									<option>23</option>
									<option>24</option>
									<option>25</option>
                                </select>-->
                            </div>						                            
                        </form>
                    </div>
					
                    
					<br><br>
					<div class="col-lg-6">					
						<div class="form-group input-group">                                
							<label>Player Value </label>(in euros) 
							<input type="text" class="form-control" id="pvalue" disabled>
						</div>						
						<button type="button" class="btn btn-primary">Evaluate</button>						
					</div>
					
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<script>			
	
	//$(document).ready(function(){
    $('button').click(function(){
		
		var player = $("#pname").val();
		var rating = $("#rating").val();
		var potential = $("#potential").val();
		var age = $("#age").val();
				
        $.post("classplayerwebservcall.php",
        {
		player1:player,
		rating1:rating,
		potential1:potential,
		age1:age		
        },
        function(data, status){
            recodata(data)
        });
    });
//});

		function recodata(data){			
			var data1 = JSON.stringify(data);			
			var data1_array = data1.split(',');
			console.log(data1);	
		for(var i = 0; i < data1.length; i++) {   			
			//alert(data1_array[i]);
			document.getElementById('pvalue').value = data1_array[16];			
			
			}			
		}
		 
		 
		 
	</script>

</body>

</html>
