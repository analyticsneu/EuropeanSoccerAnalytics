A redesign of the radar chart function that was created by alangrafu, used in my blog on [Making the D3 Radar Chart look a bit better](http://www.visualcinnamon.com/2013/09/making-d3-radar-chart-look-bit-better.html)

An even newer version created 2 years later can be found [here](http://bl.ocks.org/nbremer/21746a9668ffdf6d8242)