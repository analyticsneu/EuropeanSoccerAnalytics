<?php 
$servername="analyzesoccer.database.windows.net";

$connectionInfo=array("Database"=>"analyzesoccer","UID"=>"soccer","PWD"=>"himaja@12345");

$conn = sqlsrv_connect($servername, $connectionInfo);

if($conn){
	echo "Connect.<br/>";
}else{
	echo "Connection fail.<br/>";
	die(print_r(sqlsrv_errors(), true));
}

$tsql2 = "SELECT distinct([home_team_name]), [home_team_api_id] FROM englishpremierleague";

$gethteam = sqlsrv_query($conn, $tsql2);
$getateam = sqlsrv_query($conn, $tsql2);
//sqlsrv_free_stmt($getleague);
				
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Analyse Soccer</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	<link rel="icon" type="image/png" href="img/Soccer-icon.png">
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="about.html"><b>Sports Analytics - Predicting and Classifying A Soccer Dataset</b></a>
            </div>
            
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="about.html">&nbsp;<i class="fa fa-info-circle" aria-hidden="true"></i> &nbsp;About</a>
                    </li>
					<li>
                        <a href="index.html"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>                    
                    <li class="active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><!--<i class="fa fa-fw fa-arrows-v"></i>-->
						<i class="fa fa-area-chart" aria-hidden="true"></i> Prediction<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
								<a href="predictscore.php"><!--<i class="fa fa-fw fa-edit"></i>-->
								<i class="fa fa-circle-o" aria-hidden="true"></i> Match Score</a>
							</li>
                            <li>
								<a href="predictbetodds.html"><!--<i class="fa fa-fw fa-edit"></i>-->
								<i class="fa fa-circle-o" aria-hidden="true"></i> Betting Odds</a>
							</li>
                        </ul>
                    </li>
					<li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo1"><!--<i class="fa fa-fw fa-arrows-v"></i>-->
						<i class="fa fa-area-chart" aria-hidden="true"></i> Classification <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo1" class="collapse">
                            <li>
								<a href="classifyplayerval.php"><!--<i class="fa fa-fw fa-edit"></i>-->
								<i class="fa fa-circle-o" aria-hidden="true"></i> Player Valuation</a>
							</li>
                            <li>
								<a href="classifygameresult.php"><!--<i class="fa fa-fw fa-edit"></i>-->
								<i class="fa fa-circle-o" aria-hidden="true"></i> Game Result</a>
							</li>
                        </ul>
                    </li>                    					
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <div>
						<h1 class="page-header">
                            <strong>Match Score Prediction</strong>
							<?php
/*
							echo "PHP works here";
											
				$league1='1';
				$season1='2013/2014';
				$hteam1='8667';
				$ateam1='8197';
				$b365h1='1.1';
				$b365d1='1.1';
				$b365a1='1.1';
				$bwh1='1.1';
				$bwd1='1.1';
				$bwa1='1.1';
				
				$pyscript = 'D:\\home\\site\\wwwroot\\analyzesoccer\\python\\predictscore.py';
				$python = 'D:\\Python34\\python.exe';
				
				//**there has to be a space after $pyscript**
				$cmd = "$python $pyscript " .$league1." ".$season1." ".$hteam1." ".$ateam1." ".$b365h1." ".$b365d1." ".$b365a1." ".$bwh1." ".$bwd1." ".$bwa1;
				echo $cmd;
				
				exec("$cmd", $output);
				echo $output[0];
				$comma = ',';
				//echo $output[1].$comma.$output[2].$comma.$output[3].$comma.$output[4].$comma.$output[5].$comma.$output[6].$comma.$output[7].$comma.$output[7];
							
							
					*/		
							?>
                        </h1>
						</div>                        
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-4">

                        <form role="form">

							<div class="form-group">                                
                                <label>League </label>
								<select class="form-control" id="lid">
									<option>1</option>
									<option>English Premier League</option>
									<option>Italy Serie A</option>
									<option>Spain Liga BBVA</option>
								</select>
                            </div>
																	
							<div align="center" class="form-group">
                                <label>Home Team</label>
                                <select class="form-control" id="htid">
                                    <option value="">Select Home Team</option>
									<?php 
							if ($gethteam == FALSE)  
							die(FormatErrors(sqlsrv_errors()));  							
							while($row = sqlsrv_fetch_array($gethteam, SQLSRV_FETCH_ASSOC))  
								{  
								echo "<option value=" . $row['home_team_api_id'] . ">" . $row['home_team_name'] . "</option>"; 
								} 
									?>									
                                </select>
                            </div>
						<br><br>
							
							<div class="form-group">
                                <label>Bet365 H</label>
                                <select class="form-control" id="b365h">
                                    <option>1.1</option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
                                </select>
                            </div>
						
							<div class="form-group">
                                <label>Bet365 D</label>
                                <select class="form-control" id="b365d">
                                    <option>1.1</option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
                                </select>
                            </div>
							
							<div class="form-group">
                                <label>Bet365 A</label>
                                <select class="form-control" id="b365a">
                                    <option>1.1</option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
                                </select>
                            </div>						                            
                        </form>
                    </div>
					
                    <div class="col-lg-4">
                        <!--<h1></h1>-->

                        <form role="form">

							<div class="form-group">
                                <label>Season</label>
                                <select class="form-control" id="seasn">
                                    <option>2013/2014</option>
									<option>2014/2015</option>
									<option>2015/2016</option>
									<option>2016/2017</option>
                                </select>
                            </div>
							
							<div align="center" class="form-group">
                                <label>Away Team</label>
                                <select class="form-control" id="atid">
								<option value="">Select Away Team</option>
                                    <?php 
							if ($getateam == FALSE)  
							die(FormatErrors(sqlsrv_errors()));  							
							while($row = sqlsrv_fetch_array($getateam, SQLSRV_FETCH_ASSOC))  
								{  
								echo "<option value=" . $row['home_team_api_id'] . ">" . $row['home_team_name'] . "</option>"; 
								} 
									?>									
                                </select>
                            </div>
						

						<br><br>
						
							<div class="form-group">
                                <label>BetWay H</label>
                                <select class="form-control" id="bwh">
                                    <option>1.1</option>
                                </select>
                            </div>
							
							<div class="form-group">
                                <label>BetWay D</label>
                                <select class="form-control" id="bwd">
                                    <option>1.1</option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
                                </select>
                            </div>
							
							<div class="form-group">
                                <label>BetWay A</label>
                                <select class="form-control" id="bwa">
                                    <option>1.1</option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
									<option></option>
                                </select>
                            </div>																			
                    </div>
					<br><br>
					<div class="col-lg-2">					
						<div class="form-group input-group">                                
							<label>Match Score: </label> <input type="text" class="form-control" id="mscore" disabled>
						</div>						
						<button type="button" class="btn btn-primary">Predict Match Score</button>						
					</div>
					
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<script>			
	
	//$(document).ready(function(){
    $('button').click(function(){
		
		var league = $("#lid").val();
		var season = $("#seasn").val();
		var hteam = $("#htid").val();
		var ateam = $("#atid").val();
		
		var b365h = $("#b365h").val();
		var b365d = $("#b365d").val();
		var b365a = $("#b365a").val();
		
		var bwh = $("#bwh").val();
		var bwd = $("#bwd").val();
		var bwa = $("#bwa").val();
		
		
        $.post("predictscorewebservcall.php",
        {
		league1:league,
		season1:season,
		hteam1:hteam,
		ateam1:ateam,
		b365h1:b365h,
		b365d1:b365d,
		b365a1:b365a,
		bwh1:bwh,
		bwd1:bwd,
		bwa1:bwa		
        },
        function(data, status){
            recodata(data)
        });
    });
//});

		function recodata(data){			
			var data1 = JSON.stringify(data);			
			var data1_array = data1.split(',');
			console.log(data1);	
		for(var i = 0; i < data1.length; i++) {   			
			//alert(data1_array[i]);
			document.getElementById('mscore').value = data1_array[9] +':'+ data1_array[10];			
			
			}			
		}
		 
		 
		 
	</script>

</body>

</html>
