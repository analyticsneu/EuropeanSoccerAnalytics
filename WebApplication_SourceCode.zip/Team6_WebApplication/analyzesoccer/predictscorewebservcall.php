<?php			

//echo $_POST['name'];

$league1=$_POST['league1'];
$season1=$_POST['season1'];
$hteam1=$_POST['hteam1'];
$ateam1=$_POST['ateam1'];
$b365h1=$_POST['b365h1'];
$b365d1=$_POST['b365d1'];
$b365a1=$_POST['b365a1'];
$bwh1=$_POST['bwh1'];
$bwd1=$_POST['bwd1'];
$bwa1=$_POST['bwa1'];


				$pyscript = 'D:\\home\\site\\wwwroot\\analyzesoccer\\python\\predictscore.py';
				$python = 'D:\\Python34\\python.exe';
				
				//**there has to be a space after $pyscript**
				$cmd = "$python $pyscript " .$league1." ".$season1." ".$hteam1." ".$ateam1." ".$b365h1." ".$b365d1." ".$b365a1." ".$bwh1." ".$bwd1." ".$bwa1;
				//echo $cmd;
				
				exec("$cmd", $output);
				//echo $output[0];
				$comma = ',';
				echo $output[1].$comma.$output[2].$comma.$output[3].$comma.$output[4].$comma.$output[5].$comma.$output[6].$comma.$output[7].$comma.$output[8].$comma.$output[9].$comma.$output[10].$comma.$output[11].$comma.$output[12];
				
?>