<?php			

//echo $_POST['name'];

$player=$_POST['player1'];
$rating1=$_POST['rating1'];
$potential1=$_POST['potential1'];
$age1=$_POST['age1'];

				$pyscript = 'D:\\home\\site\\wwwroot\\analyzesoccer\\python\\classifyplayerval.py';
				$python = 'D:\\Python34\\python.exe';
				
				//**there has to be a space after $pyscript**
				$cmd = "$python $pyscript " .$player." ".$rating1." ".$potential1." ".$age1;
				//echo $cmd;
				
				exec("$cmd", $output);
				//echo $output[0];
				$comma = ',';
				echo $output[1].$comma.$output[2].$comma.$output[3].$comma.$output[4].$comma.$output[5].$comma.$output[6].$comma.$output[7].$comma.$output[8].$comma.$output[9].$comma.$output[10].$comma.$output[11].$comma.$output[12].$comma.$output[13].$comma.$output[14].$comma.$output[15].$comma.$output[16].$comma.$output[17].$comma.$output[18];				
?>