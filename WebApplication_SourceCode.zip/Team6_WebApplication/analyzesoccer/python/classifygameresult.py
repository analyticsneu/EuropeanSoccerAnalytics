import urllib.request
# If you are using Python 3+, import urllib instead of urllib2

import json  
import sys

league_id = sys.argv[1]
season = sys.argv[2]
home_team_api_id = sys.argv[3]
away_team_api_id = sys.argv[4]
b365h = sys.argv[5]
b365d = sys.argv[6]
b365a = sys.argv[7]
bwh = sys.argv[8]
bwd = sys.argv[9]
bwa = sys.argv[10]


data =  {

        "Inputs": {

                "input1":
                {
                    "ColumnNames": ["league_id", "season", "home_team_api_id", "away_team_api_id", "B365H", "B365D", "B365A", "BWH", "BWD", "BWA"],
                    "Values": [ [ league_id, season, home_team_api_id, away_team_api_id, b365h, b365d, b365a, bwh, bwd, bwa], ]
                },        },
            "GlobalParameters": {
}
    }

body = str.encode(json.dumps(data))

url = 'https://ussouthcentral.services.azureml.net/workspaces/421d1d461c7d416aa6c9555030cf3e2f/services/36abd468f3694aacb48805cb0d30ae5c/execute?api-version=2.0&details=true'
api_key = 'z+YMO/3hFZHEnnjqCo8SMa1m5TquQAODYhWzoqh/NMl6PlBuNBQyQXjgW3uozMvmNQ4UtGtjv8iTkDsVBOPUEA==' # Replace this with the API key for the web service
headers = {'Content-Type':'application/json', 'Authorization':('Bearer '+ api_key)}

req = urllib.request.Request(url, body, headers)

response = urllib.request.urlopen(req)
result = response.read().decode('utf-8')

# If you are using Python 3+, replace urllib2 with urllib.request in the above code:
# req = urllib.request.Request(url, body, headers) 
# response = urllib.request.urlopen(req)
#result = response.read()
    
json_obj = json.loads(result)
#print(json_obj)
print(json_obj['Results']['output1']['value']['Values'][0][0])
print(json_obj['Results']['output1']['value']['Values'][0][1])
print(json_obj['Results']['output1']['value']['Values'][0][2])
print(json_obj['Results']['output1']['value']['Values'][0][3])
print(json_obj['Results']['output1']['value']['Values'][0][4])
print(json_obj['Results']['output1']['value']['Values'][0][5])	
print(json_obj['Results']['output1']['value']['Values'][0][6])
print(json_obj['Results']['output1']['value']['Values'][0][7])
print(json_obj['Results']['output1']['value']['Values'][0][8])
print(json_obj['Results']['output1']['value']['Values'][0][9])
print(json_obj['Results']['output1']['value']['Values'][0][10])
print(json_obj['Results']['output1']['value']['Values'][0][11])
print(json_obj['Results']['output1']['value']['Values'][0][12])
print(json_obj['Results']['output1']['value']['Values'][0][13])