import urllib.request
# If you are using Python 3+, import urllib instead of urllib2

import json  
import sys

player_id = sys.argv[1]
overall_rating = sys.argv[2]
potential = sys.argv[3]
age = sys.argv[4]


data =  {

        "Inputs": {

                "input1":
                {
                    "ColumnNames": ["player_api_id", "overall_rating", "potential", "age"],
                    "Values": [ [ player_id, overall_rating, potential, age],]
                },        },
            "GlobalParameters": {
}
    }

body = str.encode(json.dumps(data))

url = 'https://ussouthcentral.services.azureml.net/workspaces/421d1d461c7d416aa6c9555030cf3e2f/services/a985bb235e4f4c5b8003513b513e68ea/execute?api-version=2.0&details=true'
api_key = 'CzIqlKgqEbn0xW0C9rC9ckERXycVXl2Va8QIglv9ICMr4DXAUPjBK33H6BO4LHP0fnBOFU5Tt1ppRr9uDWJ1kA==' # Replace this with the API key for the web service
headers = {'Content-Type':'application/json', 'Authorization':('Bearer '+ api_key)}

req = urllib.request.Request(url, body, headers)

response = urllib.request.urlopen(req)
result = response.read().decode('utf-8')

# If you are using Python 3+, replace urllib2 with urllib.request in the above code:
# req = urllib.request.Request(url, body, headers) 
# response = urllib.request.urlopen(req)
#result = response.read()
    
json_obj = json.loads(result)
print(json_obj)
print(json_obj['Results']['output1']['value']['Values'][0][0])
print(json_obj['Results']['output1']['value']['Values'][0][1])
print(json_obj['Results']['output1']['value']['Values'][0][2])
print(json_obj['Results']['output1']['value']['Values'][0][3])
print(json_obj['Results']['output1']['value']['Values'][0][4])
print(json_obj['Results']['output1']['value']['Values'][0][5])
print(json_obj['Results']['output1']['value']['Values'][0][6])
print(json_obj['Results']['output1']['value']['Values'][0][7])
print(json_obj['Results']['output1']['value']['Values'][0][8])
print(json_obj['Results']['output1']['value']['Values'][0][9])
print(json_obj['Results']['output1']['value']['Values'][0][10])
print(json_obj['Results']['output1']['value']['Values'][0][11])
print(json_obj['Results']['output1']['value']['Values'][0][12])
print(json_obj['Results']['output1']['value']['Values'][0][13])
print(json_obj['Results']['output1']['value']['Values'][0][14])
print(json_obj['Results']['output1']['value']['Values'][0][15])
print(json_obj['Results']['output1']['value']['Values'][0][16])